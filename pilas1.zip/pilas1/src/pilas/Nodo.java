
package pilas;

class Nodo {
    String dato;
    Nodo sig;

    public Nodo(String d) {
        dato = d;
        sig = null;
    }
}